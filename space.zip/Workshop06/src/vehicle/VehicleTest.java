package vehicle;

public class VehicleTest {
	public static void main(String[] args) {
		Truck car = new Truck();
		
	}
	
}
