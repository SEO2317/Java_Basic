package com.tight;

public class MySQLDAO {
	// MySQL DB 연동하는 메서드
	public void mysql_connect() {
		System.out.println("MySQLDAO.mysql_connect");
	}
	
}
