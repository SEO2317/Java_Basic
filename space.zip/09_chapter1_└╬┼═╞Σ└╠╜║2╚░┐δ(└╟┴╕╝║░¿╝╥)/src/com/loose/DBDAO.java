package com.loose;

public interface DBDAO {
	
	public abstract void connect_db();
	
	
}
