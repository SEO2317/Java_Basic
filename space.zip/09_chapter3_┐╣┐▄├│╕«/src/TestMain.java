
public class TestMain {

	public static void main(String[] args) {
		System.out.println("main 시작");
		
		int num = 2;
		int result = 10/num;
		System.out.println(result);
		
		System.out.println("main end: 정상종료");

	}//end main

}//end class


//정상종료