
public class Dog extends Pet{

	public Dog() {
		super(); //써도 되고 안써도 자동으로 삽입이 된다
	}
	
	

}
