package com.unabstract;

public class Dog extends Pet{

//	@Override
//	public void eat() {
//		System.out.println("냠냡~");
//	}
	
	//재정의안하고 자기 멋대로 메서드 추가
	public void eatDog() {
		System.out.println("쩝쩝~");
	}
}
