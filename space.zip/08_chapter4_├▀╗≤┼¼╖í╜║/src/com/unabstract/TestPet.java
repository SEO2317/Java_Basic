package com.unabstract;

public class TestPet {
	public static void main(String[] args) {
		
		Cat c = new Cat();
		c.eatCat();
		
		Dog d = new Dog();
		d.eatDog();
	}
}
