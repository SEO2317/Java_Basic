package com.abstract2;

public class Dog extends Pet {

	@Override
	public void eat() {
		// TODO Auto-generated method stub  //컴파일 에러가 안나기 위해 재정의를 해주어야 한다.

	}

}
