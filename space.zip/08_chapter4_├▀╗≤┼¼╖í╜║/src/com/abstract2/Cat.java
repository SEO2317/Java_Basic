package com.abstract2;

public class Cat extends Pet {

	@Override
	public void eat() {
		// TODO Auto-generated method stub

	}
	
//	public int a() {return 0;}  리턴타입으로 변환이 되지 않는다.
//	public void a() {}

}
