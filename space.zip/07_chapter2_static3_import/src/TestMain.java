//import static java.lang.Interger.MAX_VALUE;
//import static java.lang.Interger.parseInt;
import static java.lang.Math.random;
import static java.lang.Math.PI;
public class TestMain {

	public static void main(String[] args) {
		
		//1.static로 변수(상수)와 메서드 사용
		
		
		System.out.println(Integer.MAX_VALUE);

		System.out.println(Integer.parseInt("100")+1);
		
		System.out.println(Math.random()); //0.0 <= 값 <= 1.0
		
		
		System.out.println(Math.PI);
		
		/*
		 * 가독성이 떨어지는 경우(안드로이드)
		 * 
		 * import static java.lang.Interger.MAX_VALUE;
		 * import static java.lang.Interger.parseInt;
		 * import static java.lang.Math.random;
		 * import static java.lang.Math.PI;
		 * 
		 * 
		 */
		
	}
}
