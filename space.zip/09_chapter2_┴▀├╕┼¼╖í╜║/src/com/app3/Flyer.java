package com.app3;

public interface Flyer {
	public abstract void a();
	public abstract void b();
}
