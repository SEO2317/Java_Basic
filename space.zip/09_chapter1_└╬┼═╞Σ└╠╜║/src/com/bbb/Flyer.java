package com.bbb;

public interface Flyer {
	public abstract void a();
}
