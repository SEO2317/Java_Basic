//하위클래스를 강제를 한다.

/*
 * 
 * 
 * 
 * 
 * 
 */


package com.bbb;

public class FlyImpl extends Student implements Flyer, Flyer2 {
	
//public abstract class FlyImpl extends Student implements Flyer, Flyer2 {

	@Override
	public void b() {
		

	}

	@Override
	public void a() {
		

	}

}

