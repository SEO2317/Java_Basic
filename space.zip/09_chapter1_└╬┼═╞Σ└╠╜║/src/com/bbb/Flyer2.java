package com.bbb;

public interface Flyer2 {
	public abstract void b();
}
