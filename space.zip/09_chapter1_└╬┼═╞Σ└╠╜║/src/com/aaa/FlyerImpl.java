package com.aaa;

public class FlyerImpl implements Flyer {

	@Override
	public void a() {
		System.out.println("FlyImpl.a()");

	}

	@Override
	public void b(String s) {
		System.out.println("FlyImpl.b()");

	}

	@Override
	public void c() {
		System.out.println("FlyImpl.c()");

	}

}
