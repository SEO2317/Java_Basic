public class Hello {

	//main 메서드
	public static void main(String[] args) {
		// 주석문(설명 또는 실행하고 싶지 않음 문장이 있을때)
		System.out.println("Hello World");
		System.out.println("서영석"); //문자열은 "" 쌍따옴표 사용한다.
		System.out.println(25); //정수는 숫자 따옴표 없다.
		System.out.println('남'); //문자은 '' 홑따옴표 사용한다  
		System.out.println(true); //false //논리 맞다(true) 틀리다(false)
		System.out.println(190.1); //false //실수는 .사용한다
		System.out.println(""+null); //값이 없다
	}

}