
public class 문장1_순차문 {

	public static void main(String[] args) {
		// 순차문? 순차적으로 실행되는 문장을 의미한다.
		/*
		 * (1) 한번 실행된 문장은 다시 실행불가
		 * (2) 문장은 끝은 ;(세미콜론)으로 끝난다.
 		 * 
		 * 
		 */
		System.out.println("1");
		System.out.println("2");
		System.out.println("3");
		
		
		System.out.println("end");
		

	}

}
