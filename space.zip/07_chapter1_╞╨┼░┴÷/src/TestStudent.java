
import com.stu.Student; //경로

//import.패키명.클래스명  //ctrl shift 영문자 ㅇ //stu ctrl space

//default 패키지
public class TestStudent {

	public static void main(String[] args) {
		Student stu = new Student();
	
		
		com.professor.Professor p =  new com.professor.Professor();
		
		com.professor.Professor p2 =  new com.professor.Professor();
		//경로 맞추어서 
		
	}

}
