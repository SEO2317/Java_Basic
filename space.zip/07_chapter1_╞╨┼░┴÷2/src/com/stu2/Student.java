package com.stu2;

public class Student {
	
	public String name = "이순신";

}
