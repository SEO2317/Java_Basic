import com.stu.Student;

public class TestStudent {

	public static void main(String[] args) {
		
		Student s = new Student();
		
		com.stu2.Student s2 =  new com.stu2.Student(); //패키지는 다른데 클래스가 동일 한경우 하나는 import 클래스
		
		//import문 쓰거나 
		
		
		

	}

}
