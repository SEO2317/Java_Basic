
public class Println메서드 {

	public static void main(String[] args) {
		// 모니터에 출력하는 표준출력방법
		/*
		 * 1.System.out.println(값)
		 * 
		 * 새로운 라인을 생성하고 출력한다.
		 * 따라서 라인 바뀐다
		 * 
		 * 2.System.out.print(값)
		 *  새로운 라인을 생성하지 않고 출력한다.
		 * 따라서 한 줄에 출력된다.
		 */
	
		//1.System.out.println(값)
			System.out.println("1");
			System.out.println("2");
			System.out.println("3");
	}
	

}
