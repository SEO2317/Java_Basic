
public class MyTest02 {

	public static void main(String[] args) {
		//숫자값이 굉장히 클때 마지막 L 지정하여  long 타입을 알려준다
		long num = 9801171192427L;
		System.out.println("나의 주민번호: " + num);
	}

}
