import java.util.Arrays;

public class ArrayTest3_argumnets배열 {

	public static void main(String[] args) {

		System.out.println(Arrays.toString(args));
	}
	

}

//출력하고자 하는 방법 
//1. Run as -> Run Configurations -> arguments)
//arguments string prompot

	