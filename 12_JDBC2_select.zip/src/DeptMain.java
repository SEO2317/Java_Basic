//import java.awt.List;
//
//import com.dto.DeptDTO;
//import com.service.DeptService;
//import com.service.DeptServiceImpl;
//
//public class DepMain {
//
//	public static void main(String[] args) {
//		
//		//전체 조회
//		DeptService service =  new DeptServiceImpl();
//		
//		List<DeptDTO> list = service.deptAll();
//		for(DeptDTO dept : list) {
//			System.out.println(dept);
//		}
//	}
//
//}

import java.util.List;

import com.dto.DeptDTO;
import com.service.DeptService;
import com.service.DeptServiceImpl;

public class DeptMain {

	public static void main(String[] args) {

		//전체 조회
		DeptService service =
				new DeptServiceImpl();
		List<DeptDTO> list = service.deptAll();
		for (DeptDTO dept : list) {
			System.out.println(dept);
		}
	}

}

