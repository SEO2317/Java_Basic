//package com.service;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//
//import com.dao.DeptDAO;
//
//public class DeptServiceImpl implements DeptService {
//	
//	String driver = "oracle.jdbc.driver.OracleDriver";
//	String url = "jdbc:oracle:thin:@localhost:1521:xe";
//	String userid = "SCOTT";
//	String passwd = "TIGER";
//	
//
//	
//	//생성자
//	public DeptServiceImpl() {
//		try {
//			Class.forName(driver);
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//	}//end 생성자
//	
//	//dept 테이블 전체 조회
//	//Connection 얻기 작업까지만 진행한다.
//	@Override
//	List<DeptDTO> deptAll() {
//		Connection con =  null;
//		List<DeptDTO> list = null;
//		try {
//			con = DriverManager.getConnection(url, userid, passwd);
//			
//			DeptDAO dao =  new DeptDAO();
//			List<DeptDTO> list = dao.deptAll(con);
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}finally {
//			
//			try {
//				if(con != null)con.close();
//			} catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		return list;
//	}//end	
//}//end 클래스

import com.dto.DeptDTO;

public class DeptServiceImpl implements DeptService {

	String driver = "oracle.jdbc.driver.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:xe";
	String userid = "SCOTT";
	String passwd = "TIGER";
	
	//생성자
	public DeptServiceImpl() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}//end 생성자
	
	// dept테이블 전체조회
	// Connection 얻기 작업까지만 진행한다.
	@Override
	public List<DeptDTO> deptAll() {
		List<DeptDTO> list = null;
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			DeptDAO dao = new DeptDAO();
			list = dao.deptAll(con);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if( con !=null)  con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}//end deptAll() 
	
}//end 클래스
