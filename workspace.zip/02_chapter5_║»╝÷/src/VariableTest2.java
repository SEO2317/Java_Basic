
public class VariableTest2 {

	public static void main(String[] args) {
		//변수선언과 초기화에 한꺼번에
		//문법: 데이터 타입 변수명 = 값;
		
		String name = "홍길동";
		int age = 20;
		String address = "서울";
		float height =174.F;
		double weight = 75.2;
		boolean isMarried = true;
		
		System.out.println("이름:"+name);
		System.out.println("나이:"+age);
		System.out.println("주소:"+address);
		System.out.println("키:"+height);
		System.out.println("체중:"+weight);
		System.out.println("결혼여부:"+isMarried);

	}

}
