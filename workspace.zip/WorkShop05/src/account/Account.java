package account;

public class Account {
	private String account;
	private int balance;
	private double interestRate;
	public Account() {
		
	}
	public Account(String account, int balance, double interestRate) {
		this.account = account;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
	public double calculateInterest() {
		return((double)balance*(100-interestRate)/100);
	}
	//+deposit(money:int):void
	
	public void deposit(int deposit) {
		//입금의 조건
        if(deposit<=0 ){
            System.out.println("금액을 정확히 입력하세요.");
            return;
        }
        balance +=deposit;        
	}
	
	public void withdraw(int withdraw) {
		//출금의 조건
		if(withdraw>balance){
            System.out.println("잔액이 부족합니다.");
            return;
        }
 
        if(withdraw<=0){
            System.out.println("0원 및 마이너스단위는 출금하실 수 없습니다.");
            return;
        }
        balance -= withdraw;
	}
	
}
