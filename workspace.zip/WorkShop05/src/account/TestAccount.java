package account;

public class TestAccount {

	public static void main(String[] args) {
		
		Account account;
		
		Account a = new Account("441-0290-1203",500000,0);
		
//		a.setBalance(-60000);
//		
//		a.setBalance(+20000);
		
		
		
		System.out.printf("계좌정보 :%s 현재금액:%d",a.getAccount(),a.getBalance());
		
		
		

	}

}
