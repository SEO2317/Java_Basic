public class 연산자4_논리연산자3_부정 {

	public static void main(String[] args) {
		
		//논리연산자: ==> && (앰퍼센트), || , !
		//			==> 실행결과는 논리값 나오는거 논리 연산자 비교연산자
		
		
		/*2. ! (부정연산자)
		 * 
		 * !논리값
		 * 	!true => false
		 * 	!false => true
		 * 
		 * 예>
		 * 
		 * !(3==4) && 논리값 || 논리값
		 * 
		 * */
		
		
		
		System.out.println(!true); //false
		System.out.println(!false); //true
		
		
		
		
		
	}

	
}
