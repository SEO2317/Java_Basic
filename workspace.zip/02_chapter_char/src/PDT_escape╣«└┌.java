
public class PDT_escape문자 {

	public static void main(String[] args) {
		//escape 문자  ==> 특별한 기능을 구현한다
		
		System.out.println("HelloWorld");
		System.out.println("Hello	World"); //TAB 1번
		System.out.println("Hello   World"); //spacebar 3번
		System.out.println("Hello\tWorld"); 
		System.out.println("Hello\nWorld"); //줄 바꿈 
		System.out.println("Hello\"World"); 
		System.out.println("Hello\'World"); 
		
		//파일 경로 c:\\aaa
		System.out.println("c:\\aaa"); //

	}

}
