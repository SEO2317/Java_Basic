
public class Test05 {

	public static void main(String[] args) {
		
		System.out.println(Math.random());
		System.out.println( (int) Math.random() * 10 );

	}

}
