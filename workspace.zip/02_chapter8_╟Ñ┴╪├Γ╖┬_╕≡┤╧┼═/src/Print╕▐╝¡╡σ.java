
public class Print메서드 {

	public static void main(String[] args) {
		// 모니터에 출력하는 표준출력방법
		/*
		 * 1.System.out.println(값)
		 * 
		 * 새로운 라인을 생성하지 않고 출력한다.
		 * 따라서 한 줄에 출력된ㄷ자.
		 * 
		 * 2.System.out.print(값)
		 * 
		 */
	
		//1.System.out.print(값)
			System.out.print("1");
			System.out.print("2\n"); //이스케이프 \n을 라인을 바꿔서 출력
//			System.out.println(); //라인을 바꿔서 출력
			System.out.print("3"); //라인을 안 바꿔서 출력
			System.out.print("100");
	}
	

}
