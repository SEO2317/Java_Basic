
public class PDT_boolean {

	public static void main(String[] args) {
		// 참 / 거짓  => 논리 데이터
		
		System.out.println(true);
		System.out.println(false);

	}

}
